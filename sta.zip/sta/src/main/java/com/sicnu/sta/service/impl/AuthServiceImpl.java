package com.sicnu.sta.service.impl;

import com.sicnu.sta.dao.AuthDao;
import com.sicnu.sta.entity.Auth;
import com.sicnu.sta.entity.Role;
import com.sicnu.sta.service.AuthService;
import com.sicnu.sta.utils.AuthTreeUtil;
import com.sicnu.sta.utils.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service
public class AuthServiceImpl implements AuthService {

    private final Logger logger = LoggerFactory.getLogger(AuthServiceImpl.class);

    @Resource
    private AuthDao authDao;

    private ResponseUtil res;

    /**
     * 查询所有权限的信息
     * @return
     */
    @Override
    public ResponseUtil queryAllAuthInfo() {

        try {
            List<Auth> auths = authDao.queryAllAuthInfo();
            List<AuthTreeUtil> authTreeUtils = new ArrayList<>();
            for (Auth auth : auths) {
                authTreeUtils.add(new AuthTreeUtil(auth, new ArrayList<>()));
            }

            List<AuthTreeUtil> data = AuthTreeUtil.buildTree(authTreeUtils, 0);

            res = new ResponseUtil(1, "success", data);
        } catch (Exception e) {
            logger.error("查询所有权限信息异常：", e);
        }
        return res;
    }

    /**
     * 根据用户 id 来查询该用户的所有权限
     * @param userId
     * @return
     */
    @Override
    public ResponseUtil queryUserAuthByUserId(int userId) {

        try {
            Role role = authDao.queryUserRoleByUserId(userId);
            List<Auth> auths = authDao.queryRoleAuthByRoleId(role.getRoleId());
            List<AuthTreeUtil> authTreeUtils = new ArrayList<>();
            for (Auth auth : auths) {
                authTreeUtils.add(new AuthTreeUtil(auth, new ArrayList<>()));
            }
            List<AuthTreeUtil> data = AuthTreeUtil.buildTree(authTreeUtils, 0);
            res = new ResponseUtil(1, "success", data);
        } catch (Exception e) {
            logger.error("查询用户所有权限异常：", e);
        }
        return res;
    }

}
