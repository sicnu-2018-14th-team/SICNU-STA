package com.sicnu.sta.dao;

import com.sicnu.sta.entity.Auth;
import com.sicnu.sta.entity.Role;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AuthDao {

    /**
     * 查询所有的权限信息
     * @return
     */
    List<Auth> queryAllAuthInfo();

    /**
     * 根据角色 id 来查询角色权限
     * @param roleId
     * @return
     */
    List<Auth> queryRoleAuthByRoleId(@Param(value = "roleId") int roleId);

    /**
     * 根据用户 id 来查询用户拥有的角色
     * @param userId
     * @return
     */
    Role queryUserRoleByUserId(@Param(value = "userId") int userId);
}
