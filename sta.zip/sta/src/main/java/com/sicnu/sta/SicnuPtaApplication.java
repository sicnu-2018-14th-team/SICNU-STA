package com.sicnu.sta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SicnuPtaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SicnuPtaApplication.class, args);
    }

}
