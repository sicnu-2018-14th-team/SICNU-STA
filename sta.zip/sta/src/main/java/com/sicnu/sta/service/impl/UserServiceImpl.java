package com.sicnu.sta.service.impl;

import com.sicnu.sta.dao.UserDao;
import com.sicnu.sta.entity.User;
import com.sicnu.sta.service.UserService;
import com.sicnu.sta.utils.ResponseUtil;
import com.sicnu.sta.utils.TokenUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class UserServiceImpl implements UserService {

    private final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Resource
    private UserDao userDao;

    @Resource
    private TokenUtil tokenUtil;

    private ResponseUtil res;

    /**
     * 用户登录
     * @param email 用户登录邮箱
     * @param password 用户登录密码
     * @return
     */
    @Override
    public ResponseUtil judgeUserLogin(String email, String password) {

        try {
            User user = userDao.judgeUserLogin(email, password);
            if (user == null) {
                res = new ResponseUtil(0, "failure", "邮箱和密码不匹配，请重新尝试！");
            } else {
                String token = tokenUtil.createToken(user);
                res = new ResponseUtil(1, "success", token);
            }
        } catch (Exception e) {
            logger.error("用户登录异常：", e);
        }
        return res;
    }

    /**
     * 注册用户
     * @param user 用户
     * @return
     */
    @Override
    public ResponseUtil insertNewUser(User user) {

        try {
            User user1 = userDao.findUserByEmail(user.getEmail());
            if(user1 != null) {
                System.out.println(user);
                res = new ResponseUtil<String>(0, "failure", "该邮箱已经被注册！");
                return res;
            }
            userDao.insertNewUser(user);
            int userId = user.getUserId();
            if(userId > 0) {
                res = new ResponseUtil(1, "success");
            } else {
                res = new ResponseUtil(0, "failure");
            }
        } catch (Exception e) {
            logger.error("注册用户异常：", e);
        }
        return res;
    }


    /**
     * 更新用户密码
     * @param email
     * @param password
     * @return
     */
    @Override
    public ResponseUtil updateUserPassword(String email, String password) {

        try {
            User user = userDao.findUserByEmail(email);
            if(user == null) {
                res = new ResponseUtil<String>(0, "failure", "该邮箱尚未被注册！");
                return res;
            }
            int flag = userDao.updateUserPassword(email, password);
            if(flag == 1) {
                res = new ResponseUtil(1, "success");
            } else {
                res = new ResponseUtil(0, "failure");
            }
        } catch (Exception e) {
            logger.error("更新用户密码异常：", e);
        }
        return res;
    }

}
