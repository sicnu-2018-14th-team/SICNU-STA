package com.sicnu.sta.service;

import com.sicnu.sta.utils.ResponseUtil;

public interface AuthService {

    /**
     * 查询所有的题目集
     * @return
     */
    ResponseUtil queryAllAuthInfo();

    /**
     * 根据用户 id 来查询用户的权限
     * @param userId
     * @return
     */
    ResponseUtil queryUserAuthByUserId(int userId);
}
